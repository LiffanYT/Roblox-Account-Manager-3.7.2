﻿namespace RBX_Alt_Manager.Classes
{
    public enum AccountStatus
    {
        Online,
        Offline,
    }
}
